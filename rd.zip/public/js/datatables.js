$(document).ready( function () {
    $('#myTable').DataTable({
    	"paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false

} );
});