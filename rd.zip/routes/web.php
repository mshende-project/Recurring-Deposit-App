<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('auth.register');
});

Route::resources([
	'importusers' => 'ImportUsersController',
	'rdusers' => 'RduserController',
	'dailycollection' => 'DailyCollectionController',
]);
Route::post('/showuser', 'RduserController@showuser')->name('showuser');
Route::post('/linkaccount', 'RduserController@linkaccount')->name('linkaccount');
Route::get('/accholder', 'RduserController@accholders')->name('accholder');
Route::get('/showaccount/{user_id}', 'RduserController@showaccount')->name('showaccount');
Route::get('/showusersaccount', 'RduserController@showusersaccount')->name('showusersaccount');

Route::post('/dailycollections/fetch_data', 'DailyCollectionController@fetch_data')->name('dailycollections.fetch_data');

Route::get('/dailycollections/filterusers', 'DailyCollectionController@filterusers')->name('dailycollections.filterusers');

Route::post('/dailycollections/loadData', 'DailyCollectionController@loadData')->name('dailycollections.loadData');

Route::post('/dailycollections/pendingData', 'DailyCollectionController@pendingData')->name('dailycollections.pendingData');

Route::post('importusers/import', 'ImportUsersController@import')->name('import');

Route::post('/dailycollections/dopData', 'DailyCollectionController@dopData')->name('dailycollections.dopData');

Route::post('/dailycollections/domData', 'DailyCollectionController@domData')->name('dailycollections.domData');

Route::get('/dailycollections/filter', 'DailyCollectionController@filter')->name('dailycollections.filter');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::get('/dashboard', 'RduserController@dashboard')->name('dashboard');