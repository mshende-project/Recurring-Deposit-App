		  <!-- <footer class="main-footer">
		    <div class="float-right d-none d-sm-block">
		      <b>Version</b> 3.0.0
		    </div>
		    <strong>Copyright &copy; 2014-2019 <a href="http://adminlte.io">AdminLTE.io</a>.</strong> All rights
		    reserved.
		  </footer>
		</div> -->

		<!-- REQUIRED SCRIPTS -->

		<!-- jQuery -->
		<script src="<?php echo e(asset('/bower_components/admin-lte/plugins/jquery/jquery.min.js')); ?>"></script>
		<!-- Bootstrap 4 -->
		<script src="<?php echo e(asset('/bower_components/admin-lte/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
		<!-- AdminLTE App -->
		<script src="<?php echo e(asset('/bower_components/admin-lte/dist/js/adminlte.min.js')); ?>"></script>
	</body>
</html>