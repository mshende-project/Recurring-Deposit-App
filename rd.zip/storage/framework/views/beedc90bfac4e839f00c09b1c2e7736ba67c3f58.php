<?php $__env->startSection('title', 'Import Users'); ?>
<?php $__env->startSection('content'); ?>
   
<div class="container">

    <div class="row">
        <a class="btn bt-primary btn-sm" href="<?php echo e(route('rdusers.index')); ?>">View Users</a>
    </div>


    <div class="card bg-light mt-3">
        <div class="card-header">
            Import RD Users
        </div>
        <div class="card-body">
            <?php if(session()->has('message')): ?>
                <div class="alert alert-success">
                    <?php echo e(session()->get('message')); ?>

                </div>
            <?php elseif(session()->has('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session()->get('error')); ?>

                </div>
            <?php endif; ?>

		    <?php if($errors->any()): ?>
		        <div class="alert alert-danger">
		            <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
		            <ul>
		                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                    <li><?php echo e($error); ?></li>
		                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		            </ul>
		        </div>
		    <?php endif; ?>

            <form action="<?php echo e(route('import')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="file" name="file" class="form-control">
                <br>
                <button class="btn btn-success">Import User Data</button>
                <a class="btn btn-warning" href="">Export User Data</a>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>