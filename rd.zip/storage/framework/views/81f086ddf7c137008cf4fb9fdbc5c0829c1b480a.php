<?php $__env->startSection('title', 'Daily collection'); ?>

<?php $__env->startSection('content'); ?>

<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Add daily collection</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-12">
            <!-- general form elements -->
            <div class="card card-info">
              <?php if(session()->has('success')): ?>
                  <div class="alert alert-success">
                      <?php echo e(session()->get('success')); ?>

                  </div>
              <?php elseif(session()->has('error')): ?>
                  <div class="alert alert-danger">
                      <?php echo e(session()->get('error')); ?>

                  </div>
              <?php endif; ?>
              <div class="card-header">
                <h3 class="card-title float-left">Add daily collections</h3>
                <span class="float-right">
                  Date - <?php echo e(Carbon\Carbon::now()->format('d-m-Y')); ?>

                </span>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form method="POST" action="<?php echo e(route('dailycollection.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="card-body row">
                  <div class="form-group col-md-6">
                    <label>Select User</label>
                    <select class="form-control select2" name="user_id" style="width: 100%;">
                      <option selected="selected" value="">-- Select --</option>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($user->user_id); ?>"><?php echo e($user->name); ?>

                          </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>

                  <div class="form-group col-md-6">
                    <label for="name">Rupees/month</label>
                    <input type="text" class="form-control" id="rupees" name="rupees" placeholder="Enter rupees" value="<?php echo e(old('rupees')); ?>">
                    <?php if($errors->has('rupees')): ?>
                        <span class="text-danger"><?php echo e($errors->first('rupees')); ?></span>
                    <?php endif; ?>
                  </div>

                  <input type="hidden" name="date" value="<?php echo e(Carbon\Carbon::now()); ?>" id="date">
                
                </div>
                
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Submit</button>
                </div>
              </form>
            </div>
            <!-- /.card -->
          </div>
          <!-- /.row -->
          <!-- <div class="col-md-4">
            <div class="input-daterange">
              <input type="text" class="form-control float-right" id="selectdate" name="selectdate" placeholder="Select date" value="">
            </div>
          </div> -->
          <div class="col-12" style="margin-top: 3%;">

            <table id="users" class="table table-bordered table-striped">
              <thead>
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Rupees</th>
              </tr>
              </thead>
              <tbody>              
                <?php $__currentLoopData = $dailyusers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($user->id); ?></td>
                  <td><?php echo e($user->name); ?></td>
                  <td><?php echo e($user->rupees); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
              <tfoot>
                <tr>
                  <td id="total" colspan="3" style="text-align: center;"></td>
                </tr>
              </tfoot>
            </table>
          </div>

      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>