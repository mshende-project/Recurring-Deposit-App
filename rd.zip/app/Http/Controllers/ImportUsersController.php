<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel as Excel;
use Validator;
use Redirect;
use App\Imports\UsersImport;
use Exception;

class ImportUsersController extends Controller
{
    //

    public function index() {

    	return view('import.create');
    
    }

    public function import(Request $request) {
        
    	$validator = Validator::make($request->all(), [
    		'file' => 'required'
    	]);

    	if($validator->fails()) {

    		return Redirect::back()
    		->withInput()
    		->withErrors($validator);
    	
    	} else {

            try {

                Excel::import(new UsersImport, $request->file('file'));
                return back()->with('message', 'Users Imported Successfully!!');
            
            } catch(Exception $e) {

                return back()->with('error', 'Error Found!! Please check your file or you are trying to import duplicate data');
            }
        }

    }
}
