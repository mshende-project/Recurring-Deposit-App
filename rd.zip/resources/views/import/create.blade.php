@extends('master')
@section('title', 'Import Users')
@section('content')
   
<div class="container">

    <div class="row">
        <a class="btn bt-primary btn-sm" href="{{ route('rdusers.index') }}">View Users</a>
    </div>


    <div class="card bg-light mt-3">
        <div class="card-header">
            Import RD Users
        </div>
        <div class="card-body">
            @if(session()->has('message'))
                <div class="alert alert-success">
                    {{ session()->get('message') }}
                </div>
            @elseif(session()->has('error'))
                <div class="alert alert-danger">
                    {{ session()->get('error') }}
                </div>
            @endif

		    @if ($errors->any())
		        <div class="alert alert-danger">
		            <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
		            <ul>
		                @foreach ($errors->all() as $error)
		                    <li>{{ $error }}</li>
		                @endforeach
		            </ul>
		        </div>
		    @endif

            <form action="{{ route('import') }}" method="POST" enctype="multipart/form-data">
                @csrf
                <input type="file" name="file" class="form-control">
                <br>
                <button class="btn btn-success">Import User Data</button>
                <a class="btn btn-warning" href="">Export User Data</a>
            </form>
        </div>
    </div>
</div>

@endsection